justice_league  =  ["Superman",  "Batman",  "WonderWoman", "Flash", "Aquaman", "Green Lantern"] 

print(len(justice_league))

justice_league.extend(["Batgirl","Nightwing"] )
print("After Adding Batgirl and Nightwing :")
print(f"{justice_league}\n")

justice_league.remove("WonderWoman")
justice_league.insert(0,"WonderWoman")
print("Making WonderWomen As Leader :")
print(f"{justice_league}\n")

justice_league.remove("Superman")
justice_league.insert(3,"Superman")
print("After Shifting Superman :")
print(f"{justice_league}\n")

justice_league=[ "Superman","Cyborg",  "Shazam",  "Hawkgirl",  "MartianManhunter", "Green Arrow"]
print("Superman Makes a new Team : ")
print(f"{justice_league}\n")

justice_league.sort()
print("The new leader will be at the top : ")
print(f"{justice_league}\n")

print(f"The New Leader is : {justice_league[0]}")
