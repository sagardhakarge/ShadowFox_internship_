1.
def format_string(num,fmt_type):
    return format(num,fmt_type)

    """
        This function returns the octal formation of the number 145 by using the format function.
        145÷8=18 remainder 1
        18÷8=2 remainder 2
        2÷8=0 remainder 2
    
    """
c=format_string(145,"o")
print(c)
    
#=========================================================================
 
2.
r=84 
pi=3.14
area=pi*r**2
print(f"Area of Pond is : {area} m²")

wpsm=1.4
water_in_pond=int(wpsm*area)

print(f"Total water in the pond is : {water_in_pond}")

#===========================================================================

3.
d=490
t=7
speed=int(d/(t*60))
print(f"The Speed in meter per second is : {speed} m/s.")

