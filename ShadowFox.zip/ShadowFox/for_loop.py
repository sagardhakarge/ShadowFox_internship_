import random
roll=20

count_of_6=0
count_of_1=0
two_6_in_row=0

privious_roll=0

for i in range(roll):
    op=random.randint(1,6)
    print(f"Roll-{i+1} : {op}")
    
    if op == 6:
        count_of_6 +=1
    
    if op==1:
        count_of_1 +=1
    
    if op==6 and privious_roll==6:
           two_6_in_row +=1
    
    privious_roll=op    
    
print(f"\nNumber of time 6 appered : {count_of_6}")
print(f"Number of time 1 appered : {count_of_1}")
print(f"Number of time two 6 in row  : {two_6_in_row}")
print(" ")

2.
jumping_jack=100
completed=0

for i in range(1,jumping_jack+1,10):
   print("\nDo 10 Jumping jacks.")
   completed+=10
   
   if completed==jumping_jack:
       print("You did the 100 jumping jacks")
       print("Congratulation You completed the Workout.")
       break
   
   tired=input("Are You Tired ? (yes/y or no/n) :")
   
   if tired=="yes" or tired=="y":
        skip=input("\nDo You want to skip the remaining sets? (yes/y or no/n) : ")
        if skip=="yes" or skip=="y":
            print("\nYou completed ", completed, "jumping jacks")   
            break
      
   elif tired=="no" or tired=="n":
        remaining=jumping_jack-completed
        print(f"{remaining} Jumping Jacks are remaining.")
        
    
    
    
    
   
       
        
       
            
        
        