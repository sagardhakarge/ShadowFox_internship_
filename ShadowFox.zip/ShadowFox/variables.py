pi=22/7
print(pi , type(pi))

# for=4  --> it gives the syntax Error : invalid syntax for the for loop.

p=int(input("Enter the Principal Amount : "))
r=float(input("Enter the Rate Of Interest : "))
t=3

simple_Interest =(p*r*t)/100

print(f"The Simple Interest is {simple_Interest} Rs.")


total = 100
completed = 0

