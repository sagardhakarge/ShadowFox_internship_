names=["Sagar","Prashant","Aryan","Dadu","Krishana"]
    
names_with_letters=[]

for name in names:
    print(name, len(name))

print("")



2.
my_expenses={"Hotel" :10000 , "Foods":3000 , "Travel":7500 , "Clothes":4500 , "Miscellaneous":500}

friends_expenses={"Hotel" :10000 , "Foods":700 , "Travel":9500 , "Clothes":6500 , "Miscellaneous":700}

 
print(f"My Expenses : {my_expenses.keys()}  ")
print(f" Friends Expenses : {friends_expenses.keys()}  \n")

my_total=sum(my_expenses.values())
friends_total=sum(friends_expenses.values())

print(f"My total Expenses : {my_total}")
print(f"Friends total Expenses : {friends_total}")

if my_total > friends_total:
    print("You Spent the more Money !")

elif my_total< friends_total:
    print("Your Partner Spents more Money !")

else: 
    print("You Both Spent The same Amount Money !")

print(" ")

max_diff = 0
max_category = ""

for category in my_expenses:
    diff = abs(my_expenses[category] -friends_expenses[category])
    
    if diff > max_diff:
        max_diff = diff
        max_category = category

print("Category with highest difference:", max_category)
print("Difference:", max_diff)
