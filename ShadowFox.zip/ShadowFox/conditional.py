height=float(input("Enter the height in Meter : "))
weight=float(input("Enter the Weight in Kg : "))

bmi=weight/(height**2)

if  bmi>30 or bmi==30   :
    result="Obesity"
    print(f"BMI: {round(bmi,2)} , Output: {result}")
    
elif bmi<29 and bmi>25 :
    result="Overweight"
    print(f"BMI: {round(bmi,2)} , Output: {result}")

elif bmi<25 and bmi>18.5 :
    result="Normal"
    print(f"BMI: {round(bmi,2)} , Output: {result}.")
    
else:
    print(f"BMI: {round(bmi,2)} , Output: Underweight.")

print("\n")

   
2.
Australia = ["Sydney","Melbourne","Brisbane","Perth"]
UAE = ["Dubai","Abu Dhabi","Sharjah","Ajman"]
India = ["Mumbai","Bangalore","Chennai","Delhi"]

city=input("Enter the Name of City : ").capitalize()

if city in Australia:
    print(f"Output : {city} is in Australia")

elif city in UAE:
    print(f"Output : {city} is in UAE")

elif city in India:
    print(f"Output : {city} is in India")

else:
    print("City is not belongs to the given Countries.")

print("")  
3.

city1=input("Enter the First city :")
city2=input("Enter the Second city :")

if city1 and city2  in Australia:
    print(f"Both Cities are in Australia")

elif city1 and city2  in India:
    print(f"Both Cities are in India.")

elif city1 and city2  in UAE:
    print(f"Both Cities are in UAE.")

else:
    print("They don't belongs to the Same Country.")
    
